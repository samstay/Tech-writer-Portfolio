---
layout: page
title: Обо мне
permalink: /about/
---

Коротко о себе: сферы домена, стек инструментов (Markdown, Git, OpenAPI/Swagger, DITA/XML, Confluence, Figma), подходы (Docs‑as‑Code, SME‑интервью, тестирование инструкций).