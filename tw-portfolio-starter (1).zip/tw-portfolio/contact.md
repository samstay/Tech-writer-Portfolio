---
layout: page
title: Контакты
permalink: /contact/
---

- Email: your.email@example.com  
- LinkedIn: https://www.linkedin.com/in/yourusername/  
- GitHub: https://github.com/yourusername